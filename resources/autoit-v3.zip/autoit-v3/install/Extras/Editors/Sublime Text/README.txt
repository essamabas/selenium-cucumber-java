The package for AutoIt and SublimeText can be downloaded from:
https://github.com/AutoIt/SublimeAutoItScript

Merge the AutoIt.tmLanguage from this folder with that downloaded package and
add to your Sublime text setup.
